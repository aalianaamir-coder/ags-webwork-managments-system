# AGS WEBWORKS — Business Management & Order Tracking System

A complete, secure, production-ready internal management system for **AGS WEBWORKS** (Dammam & Al Khobar, Saudi Arabia) — clients, orders, projects, tasks, payments, invoices, expenses, team permissions, monthly website maintenance subscriptions with recurring billing, reports and analytics.

**Made by Aaliyan Aamir**

---

## 1. What's Inside

| Module | Capabilities |
|---|---|
| **Dashboard** | Personalized per role — CEO overview (revenue, profit, team workload, deadlines), Developer workspace (assigned projects, tasks, reviews), Accountant cockpit (payments, overdue invoices, billing) |
| **Clients Database** | Full CRUD, auto IDs (CL-0001), duplicate detection by phone/email/website, lead pipeline statuses, search & filters, CSV export, communication history |
| **Orders & Projects** | Auto IDs (AGS-ORD-0001), 12-stage workflow (skippable), Kanban board with drag & drop, table view, deadline calendar, preview/live/repo links, revision history, comments, developer-scoped updates |
| **Attendance** | GitHub-style contribution heatmap (12 months), self check-in / check-out (Asia/Riyadh, auto LATE after 09:30), worked-hours tracking with live timer, present/late/absent/leave/half-day statuses, current & longest streaks, team overview (CEO & accountant), manual marking + audit (CEO only) |
| **Tasks & Assignments** | Assignment to team members, priorities, deadlines, overdue highlighting, comments, statuses |
| **Payments & Invoices** | Payments in/out (received + refunds), methods (bank, cash, Mada, Apple Pay, STC Pay), auto balance calculation, invoices with VAT support, PDF download + print with AGS branding and the account holder's avatar |
| **Expenses & Profit** | Categories, CEO approval workflow, net profit = revenue − approved expenses |
| **Website Maintenance** | Value/Pro/Custom packages (CEO-editable prices & limits), subscriptions with lifecycle (activate/pause/resume/renew/upgrade/downgrade/cancel), **recurring monthly invoicing with duplicate prevention**, support tickets with monthly allowance tracking, MRR analytics |
| **Team & Security** | 3 role accounts + **admin can create new member accounts** (one-time temporary password shown once, forced change at first sign-in), scrypt password hashing, DB-backed sessions, login & reset **rate limiting**, server-side permission matrix, forced first-login password change, admin-issued reset codes, **uploadable profile pictures** (JPG/PNG/WebP ≤ 2 MB, admin can change any member's), full activity audit log |
| **Files** | Private storage (never in /public), access-controlled downloads, linked to clients/orders |
| **Reports** | Sales, revenue vs expenses, profit, orders by status, on-time delivery, lead funnel & conversion, revenue by service, workload, maintenance MRR — all with date ranges + CSV export |
| **Extras** | **Three themes — Dark (charcoal professional, default), Morning (warm sunrise) and Light (clean neutral)** with per-device persistence, English + Arabic (RTL) UI, SAR currency, Asia/Riyadh timezone, subtle WebGL shader login, interactive creator page with games, responsive mobile design, minimalist professional design system |

## 2. The Three Accounts

Accounts are created by the secure seed script (`prisma/seed.ts`) — **never hardcoded in the frontend**. Initial passwords are cryptographically random, printed once to the console, saved to `CREDENTIALS.txt` (chmod 600), and every account **must change its password at first login** (all other sessions are then invalidated).

| Member | Username | Role | Access |
|---|---|---|---|
| Sharjeel | `sharjeel` | ADMIN — CEO & Marketing | Everything: all modules, settings, team management, expense approvals, package pricing |
| Gufran | `gufran` | DEVELOPER — Web Developer | Assigned orders/projects only, dev-stage status updates, website links, tasks, assigned maintenance tickets, files. **No financial data, no settings, no user management** |
| Addan | `addan` | ACCOUNTANT — Order Coordinator | Orders & coordination, payments, invoices, expenses (create), maintenance billing & invoices, reports. **No user management, no admin settings** |

> After delivery, change passwords immediately and store `CREDENTIALS.txt` somewhere safe or delete it.

## 3. Tech Stack & What To Connect

- **Framework:** Next.js 16 (App Router) + TypeScript
- **UI:** Tailwind CSS 4, shadcn/ui, Framer Motion, Recharts, raw WebGL shaders
- **Database (ORM):** Prisma
- **Auth:** Custom secure sessions (scrypt hashes + httpOnly cookies + server-side lookups)
- **PDF:** html2canvas-pro + jsPDF

**Database connection:** the app talks to the database through Prisma using the `DATABASE_URL` environment variable.

- **Sandbox/dev (current):** SQLite file at `db/custom.db` — zero configuration, persists across refreshes and restarts.
- **Production (recommended):** PostgreSQL or Supabase. See §6 for the one-line switch.

No other external services are required. Files are stored on the server in `db/uploads/` (private). If you move to Supabase, you can optionally swap file storage to Supabase Storage — the API route `src/app/api/files/route.ts` is the only place to change.

## 4. Environment Variables

`.env` (dev — copy from `.env.example`):

```env
# SQLite — Prisma resolves this relative to prisma/schema.prisma,
# so ../db/custom.db = <project>/db/custom.db (next to db/uploads & db/avatars)
DATABASE_URL="file:../db/custom.db"
```

Production example (PostgreSQL / Supabase):

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/ags_webworks?schema=public"
NODE_ENV=production
SCHEDULER_KEY="<long-random-string>"   # optional — enables cron to trigger the
                                     # maintenance scheduler via the
                                     # "x-scheduler-key" header (see §7)
```

| Variable | Required | Purpose |
|---|---|---|
| `DATABASE_URL` | yes | SQLite file path (dev) or PostgreSQL connection string (prod) |
| `NODE_ENV` | prod | Set to `production` → secure cookies over HTTPS |
| `SCHEDULER_KEY` | optional | Secret for the recurring-invoice cron endpoint. Generate with `openssl rand -hex 32` |

Never expose `DATABASE_URL`, `SCHEDULER_KEY` or any secrets to the client — all sensitive operations run in server-side API routes.

## 5. Run Locally

```bash
bun install          # or npm install
bun run db:push      # create/refresh the schema
bun run db:seed      # create the 3 accounts + maintenance plans (prints credentials)
bun run dev          # http://localhost:3000
```

> Always start the dev server through the package script (`bun run dev` / `npm run dev`). Do **not** execute the Next binary directly with Bun (e.g. `bun next dev` or `bun node_modules/next/dist/bin/next dev`) — Bun-as-runtime + Turbopack cannot resolve the generated Prisma client and every API route will 500. The package scripts run Next under Node, which is fully supported.

Useful scripts:

```bash
bun run lint                          # ESLint
bun run test                          # production build + 34 automated API tests (isolated DB)
bun run db:push                       # push schema changes
bun run db:seed                       # idempotent seed (existing accounts are kept)
bun run db:demo                       # OPTIONAL: insert clearly-fake demo data (fresh DB only)
bun run db:demo-remove                # remove demo data
bunx tsx prisma/reset-passwords.ts    # regenerate all 3 passwords (writes CREDENTIALS.txt)
bunx tsx prisma/cleanup.ts            # wipe business data + restore seeded credentials
```

> **Safe seeding of a test database:** `CREDENTIALS_FILE=tests/creds.txt DATABASE_URL=file:./db/test.db bunx tsx prisma/seed.ts` — the credentials file path is overridable so testing never overwrites the real one.

## 6. Switching to PostgreSQL / Supabase (Production)

1. In `prisma/schema.prisma` change:
   ```prisma
   datasource db {
     provider = "postgresql"   // was "sqlite"
     url      = env("DATABASE_URL")
   }
   ```
2. Set `DATABASE_URL` to your PostgreSQL/Supabase connection string.
3. Run `bun run db:push` (fresh database) or `bunx prisma migrate dev --name init` for versioned migrations.
4. Run the seed: `bunx tsx prisma/seed.ts`.
5. Restart the app. Everything else (queries, permissions, indexes, unique constraints — including the duplicate-invoice guard) works unchanged because all data access goes through Prisma.

## 7. Deployment

**Option A — VPS (recommended for the cron scheduler):**

```bash
git clone <your-repo> && cd ags-management
bun install
# configure .env with PostgreSQL + NODE_ENV=production
bunx prisma migrate deploy      # apply migrations
bunx tsx prisma/seed.ts         # first deploy only
bun run build && bun run start  # serves on port 3000 behind Nginx/Caddy
```

**Option B — Vercel:** import the repo, set `DATABASE_URL` (Supabase/Neon), deploy. Run the seed script once from your machine against the production database.

**The recurring invoice scheduler — how to activate true 24/7 automation:**

Inside the app, maintenance invoices generate automatically whenever a CEO or accountant is signed in (the app pings `/api/maintenance/scheduler/run` every 5 minutes — idempotent, duplicate-safe), plus there is a manual **Run recurring scheduler** button in *Maintenance → Invoices*.

For full automation independent of anyone being logged in, set `SCHEDULER_KEY` in `.env` and add a server cron job (VPS):

```cron
# generate due maintenance invoices + flag overdue ones, every day at 03:00
0 3 * * * curl -s -X POST http://localhost:3000/api/maintenance/scheduler/run -H "x-scheduler-key: $SCHEDULER_KEY"
```

The endpoint accepts **either** a valid `x-scheduler-key` header (for cron) **or** a signed-in ADMIN/ACCOUNTANT session (for the in-app trigger). Without either, it returns 401. If you also want to restrict it at the reverse-proxy level:

```nginx
location /api/maintenance/scheduler/run {
    allow 127.0.0.1;   # cron only
    deny all;
    proxy_pass http://localhost:3000;
}
```

The scheduler:
- generates one invoice per active subscription per billing period (**DB unique constraint prevents duplicates forever**),
- handles months shorter than the billing day (Jan 31 → Feb 28),
- marks invoices/subscriptions overdue and notifies Sharjeel & Addan,
- records failures in the activity log for authorized retries.

## 8. Security Model

- Passwords: scrypt (64-byte derived key + per-user salt), never logged, never sent to the client.
- Brute-force protection: login and password-reset attempts are rate-limited per IP + username (10 sign-in attempts / 15 min; 6 reset attempts / 15 min) with clear 429 responses.
- Business codes (CL-0001, AGS-ORD-0001, …) are generated from the highest existing sequence — deleting records can never cause duplicate-code failures — and creation retries automatically under concurrency.
- Sessions: opaque 256-bit tokens; only SHA-256 hashes stored in the DB; httpOnly/SameSite cookies; 7-day expiry; invalidated on password change.
- Authorization: every API route calls `requirePermission()` — the UI hides pages, but the **server** enforces the role matrix (developers get 403 on financial endpoints even if they craft requests).
- Files: stored outside `/public`; downloads go through an access-checked API route with server-side path containment and `X-Content-Type-Options: nosniff`.
- **Upload content validation:** file contents are verified by magic-byte signatures (`src/lib/file-validation.ts`) — the client-declared MIME type is never trusted. A renamed executable claiming to be `image/png` is rejected with 415, as is any file with a missing/unknown type.
- **Security headers** on every response: `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy`, `Content-Security-Policy`, HSTS (serve behind HTTPS in production).
- **Error hygiene:** unexpected server errors return a generic JSON message — stack traces, Prisma internals and file paths are logged server-side only, never sent to the client.
- Password reset codes: 10-char random, 30-minute expiry, **single-use**, constant-time comparison, rate-limited (6 attempts / 15 min / IP+username).
- Expired sessions are swept from the database automatically (on login and on every scheduler pass).
- Audit: every create/update/delete/approval/login is written to `activity_logs` with user, action, entity and timestamp (visible to the CEO in Team → Activity log).
- Clients with business history are archived instead of deleted; orders with payments cannot be deleted.
- Report date ranges are inclusive of the final day (an end date of "today" includes records created today).

## 8b. Adding Team Members

*Team Members → Add member* (CEO only): enter name, username, optional email, role and job title. A strong **temporary password is generated and shown exactly once** — copy it and share it with the new member over a secure channel. Their first sign-in forces a password change. Username/email uniqueness is validated server-side, and the account creation is audit-logged. The CEO can also change roles/job titles, deactivate accounts (never the last active admin), and issue one-time password reset codes from the same screen.

## 9. Database Backup & Recovery

- **SQLite:** `sqlite3 db/custom.db ".backup backup-$(date +%F).db"` (cron daily).
- **PostgreSQL/Supabase:** `pg_dump $DATABASE_URL > backup.sql` or enable Supabase automated daily backups (Pro plan) / Point-in-time recovery.
- Restore: stop the app, replace the DB (or `psql < backup.sql`), start the app. Prisma schema is defined in code, so any clean database can be re-initialized with `db:push` + seed.

## 10. Project Structure

```
prisma/schema.prisma       # 26 tables: users, sessions, clients, orders, tasks,
                           # attendance_records, payments, invoices, expenses, files,
                           # comments, notifications, activity_logs, business_settings,
                           # maintenance_plans/subscriptions/invoices/payments/
                           # tickets/activity_logs
prisma/seed.ts             # secure account + package seeding
prisma/reset-passwords.ts  # regenerate the 3 account passwords
prisma/cleanup.ts          # test-data wipe + credential restore
src/lib/                   # auth, permissions matrix, helpers, i18n, store
src/app/api/               # ~40 secured API routes
src/app/page.tsx           # SPA entry (login → password change → app shell)
src/app/globals.css        # design system — Dark / Morning / Light theme tokens
src/components/app/        # shell, login, invoice document, WebGL background
src/components/app/views/  # 14 module views incl. attendance & creator page
db/uploads/                # private file storage
db/avatars/                # uploaded profile pictures (private, API-served)
CREDENTIALS.txt            # initial credentials (safe-delete after first logins)
```

## 11. Arabic / RTL

Toggle the globe icon in the top bar. The whole layout mirrors (sidebar, paddings, dropdowns), navigation and key labels switch to Arabic. English remains the default; add more strings in `src/lib/i18n.ts`.

## 12. Attendance Module Details

- **Check-in / check-out:** every team member checks themselves in from *Workspace → Attendance*. Times are stored in UTC and displayed in Asia/Riyadh. Checking in after **09:30** is automatically flagged **LATE**. Check-out computes the worked hours for the day (a live timer shows progress before check-out).
- **Heatmap:** the last 12 months render as a GitHub-style contribution grid — green shades by hours worked, plus distinct colors for Late, Half day, Leave and Absent. Hover any cell for the date, status and hours.
- **Team overview (CEO & accountant):** today's status of every member plus month-to-date present/late/absent counts. The CEO can select any member to view their heatmap and **manually mark** any past day (Present / Late / Half day / Leave / Absent) with a note — every manual mark is written to the audit log.
- **Permissions:** developers see only their own records; accountants get the team view read-only; only the CEO can mark/edit. Enforced server-side on every route.

## 13. Profile Pictures

Each member can upload their own photo in *Settings → My profile* (hover the avatar → camera, or *Upload new*). The CEO can change any member's picture from *Team Members*. Rules: JPG/PNG/WebP, max 2 MB, stored privately in `db/avatars/` (never in `/public`), served through the authenticated route `/api/avatars/<userId>`. *Reset* returns to the default illustrated avatar. Uploads and resets are audit-logged.

## 14. Verification Status (quality gates)

- `tsc --noEmit` — **0 errors** (strict; `ignoreBuildErrors` is OFF so type errors fail the build)
- `eslint` — **0 errors, 0 warnings**
- Production build (`next build`) — **verified**, standalone output boots, serves the login page, authenticates, and returns live data from the database
- **Automated API test suite — 34 tests / 83 assertions, all passing** (`bun run test`): authentication & rate limiting, all six permission boundaries, the full client → order → invoice → payment workflow with persistence checks, expense approval, content-based upload security, cross-user file access denial, attendance duplicate guard, team creation, single-use reset codes, scheduler key auth, and JSON error hygiene. Runs against an isolated test database — the working database is never touched.
- All 13 modules browser-tested end-to-end (create/edit/persist, role restrictions 401/403, rate limiting, PDF/CSV exports, mobile 390 px, Arabic RTL)

## 15. Credential Rotation & Delivery Hygiene

If credentials were ever exposed (leaked file, shared ZIP, laptop compromise), rotate them:

```bash
bunx tsx prisma/reset-passwords.ts   # new random passwords → CREDENTIALS.txt
                                     # destroys ALL sessions, forces first-login change
```

The clean delivery package intentionally contains **no** `CREDENTIALS.txt`, **no** database file, **no** uploaded files and **no** logs — the client generates their own credentials on first setup (`bun run db:push` + `bun run db:seed`).

Never commit secrets: `.gitignore` excludes `CREDENTIALS.txt`, `.env`, `db/` databases & runtime storage, `upload/`, logs and backups. `.env.example` documents every variable with placeholder values only.

## 16. Sanitized Demo Data (optional)

For client demos you can populate a **fresh** database with clearly-fictional records (three `[DEMO]`-tagged clients with an order, invoice, payments, an expense awaiting approval, a maintenance subscription with a paid invoice and an open ticket):

```bash
bun run db:demo           # insert demo data (refuses if real clients exist)
bun run db:demo-remove    # remove exactly the [DEMO]-tagged records
```

All names, phones, e-mails and domains are fake (`example.com`, `+966 5X 000 00XX`). The script refuses to run when the database already contains real client data.

## 17. Client Handover

See **HANDOVER.md** for the step-by-step handover checklist (first setup, password policy, backups, scheduler activation, go-live).
