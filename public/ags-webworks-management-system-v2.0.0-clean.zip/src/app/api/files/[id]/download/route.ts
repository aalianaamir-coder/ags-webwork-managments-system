import { db } from '@/lib/db'
import { handler, ApiError, requireUser } from '@/lib/permissions'
import { readFile } from 'fs/promises'
import path from 'path'

const UPLOAD_DIR = path.join(process.cwd(), 'db', 'uploads')
const UPLOAD_DIR_RESOLVED = path.resolve(UPLOAD_DIR)

type Params = { params: Promise<{ id: string }> }

/** Access-controlled download — the file never lives in /public. */
export const GET = handler(async (_req: Request, { params }: Params) => {
  const user = await requireUser()
  const { id } = await params
  const record = await db.fileRecord.findUnique({
    where: { id },
    include: { order: { select: { id: true, developerId: true, coordinatorId: true } } },
  })
  if (!record) throw new ApiError(404, 'File not found')

  if (user.role === 'DEVELOPER') {
    const own = record.uploadedById === user.id || (record.order && (record.order.developerId === user.id || record.order.coordinatorId === user.id))
    if (!own) throw new ApiError(403, 'You do not have access to this file')
  }

  // Defense-in-depth: the stored path is server-generated, but still verify the
  // resolved path stays inside the private upload directory (no traversal).
  const target = path.resolve(UPLOAD_DIR, record.filePath)
  if (!target.startsWith(UPLOAD_DIR_RESOLVED + path.sep)) {
    throw new ApiError(403, 'You do not have access to this file')
  }
  const buffer = await readFile(target).catch(() => null)
  if (!buffer) throw new ApiError(410, 'File is no longer available on the server')

  return new Response(new Uint8Array(buffer), {
    headers: {
      'Content-Type': record.mimeType,
      'Content-Disposition': `attachment; filename="${encodeURIComponent(record.fileName)}"`,
      'Content-Length': String(buffer.length),
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
    },
  })
})
