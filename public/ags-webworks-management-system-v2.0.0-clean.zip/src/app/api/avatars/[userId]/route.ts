import { db } from '@/lib/db'
import { handler, requireUser } from '@/lib/permissions'
import { readFile } from 'fs/promises'
import path from 'path'

const AVATAR_DIR = path.join(process.cwd(), 'db', 'avatars')
const TYPES: Record<string, string> = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp' }

// GET /api/avatars/[userId] — serve an uploaded profile picture (any signed-in team member)
export const GET = handler(async (_req: Request, { params }: { params: Promise<{ userId: string }> }) => {
  await requireUser()
  const { userId } = await params

  for (const [ext, mime] of Object.entries(TYPES)) {
    const buffer = await readFile(path.join(AVATAR_DIR, `${userId}.${ext}`)).catch(() => null)
    if (buffer) {
      return new Response(new Uint8Array(buffer), {
        headers: {
          'Content-Type': mime,
          'Cache-Control': 'private, max-age=60',
          'Content-Length': String(buffer.length),
          'X-Content-Type-Options': 'nosniff',
        },
      })
    }
  }

  // No custom upload — fall back to the default generated avatar
  const user = await db.user.findUnique({ where: { id: userId }, select: { username: true } })
  if (user) {
    return Response.redirect(new URL(`/avatars/${user.username}.png`, _req.url), 302)
  }
  return new Response('Not found', { status: 404 })
})
