# AGS WEBWORKS Management System — Client Handover Guide

Version 2.0.0 · Prepared for delivery · All setup steps verified on a clean checkout

---

## 1. What the client receives

A clean **source-code package** containing:

| Included | Excluded on purpose |
|---|---|
| Full application source (`src/`, `prisma/`, `public/` brand assets) | `CREDENTIALS.txt` — the client generates their own credentials at setup |
| `README.md` (administrator manual: modules, security, deployment) | Any database file (`db/custom.db`) — no business data leaves your office |
| This handover guide | `.env` with real values (only `.env.example` with placeholders) |
| `prisma/demo-data.ts` — optional clearly-fake demo dataset | Uploaded files, avatars, logs, backups, git history |
| Automated test suite (`tests/`) | |

The application stack: Next.js 16 (App Router) + TypeScript, Prisma ORM, Tailwind CSS 4 + shadcn/ui, custom secure session auth. No paid third-party services are required to run it (see §8).

## 2. First setup (15 minutes)

Prerequisites: **Node.js 20+** (or Bun 1.1+), a PostgreSQL database (recommended) or SQLite for small single-server installs.

```bash
# 1. Install dependencies
bun install            # or: npm install

# 2. Configure environment
cp .env.example .env   # then edit .env and set DATABASE_URL

# 3. Create the database schema
bun run db:push        # or: npx prisma db push

# 4. Create the admin accounts (prints one-time initial passwords)
bun run db:seed        # or: npx tsx prisma/seed.ts

# 5. Start
bun run dev            # development, http://localhost:3000
# production:
bun run build && bun run start
```

> Always start via the package scripts (`bun run dev` / `npm run dev`). Executing the Next binary directly under the Bun runtime breaks Prisma client resolution (all API routes return 500).

The seed creates three accounts (administrator / developer / accountant roles), each with a **cryptographically random initial password** that must be changed at first sign-in. Record those passwords from the console/`CREDENTIALS.txt`, hand them to the right people, then delete the file.

**Optional demo data:** `bun run db:demo` populates a *fresh* database with three clearly-fictional `[DEMO]`-tagged clients, an order, invoice, payments, a maintenance subscription and a ticket — useful for training sessions. Remove with `bun run db:demo-remove`. It refuses to run on a database that already has real clients.

## 3. Password & account policy (tell the client)

- Initial passwords are random and shown once; every user is forced to change theirs at first login.
- Passwords are stored as scrypt hashes — they can never be recovered, only reset.
- An administrator issues one-time reset codes from *Team Members* (valid 30 minutes, single use).
- All sessions are invalidated when a password changes.
- Login attempts are rate-limited (10 per 15 minutes per username); reset-code guessing is limited to 6 per 15 minutes.

## 4. Go-live checklist

1. **Database:** use PostgreSQL (Supabase / managed Postgres recommended). Switch `provider` in `prisma/schema.prisma` to `postgresql`, set `DATABASE_URL`, run `bun run db:push`, then seed.
2. **HTTPS:** serve behind Nginx/Caddy with a TLS certificate. Cookies automatically become `secure` when `NODE_ENV=production`. HSTS is already sent by the app.
3. **Scheduler:** set `SCHEDULER_KEY` (e.g. `openssl rand -hex 32`) and add the cron line from README §7 so maintenance invoices generate even when nobody is logged in.
4. **Backups:** schedule daily database backups (README §9) and verify a restore once before go-live.
5. **Monitoring:** watch the server logs (`server.log`) and check *Team → Activity log* inside the app for a full audit trail.
6. **Run the test suite once on the production build:** `bun run test` (uses an isolated test database — safe anytime).

## 5. Where things live

| Concern | Location |
|---|---|
| Roles & permissions matrix | `src/lib/permissions.ts` |
| Session & password logic | `src/lib/auth.ts` |
| Upload content validation | `src/lib/file-validation.ts` |
| Recurring-invoice scheduler | `src/app/api/maintenance/scheduler/run/route.ts` |
| Business settings (VAT, currency, invoice footer) | *Settings* in the app (CEO account) |
| Private file storage | `db/uploads/` (never inside `/public`) |
| Uploaded profile pictures | `db/avatars/` (served only to signed-in members) |

## 6. Rollback

The system is stateless apart from the database: to roll back a deployment, restore the previous build directory and the database backup taken before the upgrade. Schema changes go through Prisma — keep `prisma/migrations/` in version control once you adopt `migrate` workflows.

## 7. Support expectations

All 13 modules were verified end-to-end and the API suite (34 tests) passes on the delivered build. If the client modifies the code, `bun run lint`, `bunx tsc --noEmit` and `bun run test` are the quality gates to re-run before shipping changes.

## 8. Third-party software & paid services

All runtime dependencies are open-source (MIT/Apache-ISC style licenses — Next.js, React, Prisma, Tailwind, shadcn/ui, Recharts, jsPDF, html2canvas-pro, etc.). **No paid services are required.** Optional paid infrastructure the client may *choose*: managed PostgreSQL (e.g. Supabase Pro), VPS hosting, domain & TLS. The app itself has no license keys, phone-home code or usage limits.
