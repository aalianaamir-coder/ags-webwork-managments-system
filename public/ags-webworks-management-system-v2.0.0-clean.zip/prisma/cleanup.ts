// AGS WEBWORKS — post-test cleanup
// Removes ALL test records created during E2E verification and restores the
// original seeded credentials (from CREDENTIALS.txt) so the delivered system
// starts clean with first-login password changes enforced.

import { PrismaClient } from '@prisma/client'
import { readFileSync, existsSync, readdirSync, unlinkSync } from 'fs'
import { randomBytes, scryptSync } from 'crypto'
import path from 'path'

const db = new PrismaClient()

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `scrypt$${salt}$${hash}`
}

function parseCredentials(): Record<string, string> {
  const out: Record<string, string> = {}
  const text = readFileSync('CREDENTIALS.txt', 'utf-8')
  const re = /(\w+)\s+username: (\w+)\s+password: (\S+)/g
  let m: RegExpExecArray | null
  while ((m = re.exec(text)) !== null) {
    out[m[2]] = m[3]
  }
  return out
}

async function main() {
  console.log('Cleaning test data…')

  // ---- Business records (FK-safe order) ----
  await db.attendanceRecord.deleteMany({})
  await db.fileRecord.deleteMany({})
  await db.comment.deleteMany({})
  await db.maintenancePayment.deleteMany({})
  await db.maintenanceInvoice.deleteMany({})
  await db.maintenanceActivityLog.deleteMany({})
  await db.maintenanceTicket.deleteMany({})
  await db.maintenanceSubscription.deleteMany({})
  await db.payment.deleteMany({})
  await db.invoiceItem.deleteMany({})
  await db.invoice.deleteMany({})
  await db.orderRevision.deleteMany({})
  await db.task.deleteMany({})
  await db.order.deleteMany({})
  await db.client.deleteMany({})
  await db.notification.deleteMany({})
  await db.activityLog.deleteMany({})
  await db.session.deleteMany({})
  console.log('✓ All business records, attendance, notifications, activity logs and sessions removed')

  // ---- Remove test-created user accounts (keep only the 3 seeded accounts) ----
  const seeded = ['sharjeel', 'gufran', 'addan']
  const extraUsers = await db.user.findMany({ where: { username: { notIn: seeded } }, select: { id: true, username: true } })
  for (const u of extraUsers) {
    await db.session.deleteMany({ where: { userId: u.id } })
    await db.notification.deleteMany({ where: { userId: u.id } })
    await db.activityLog.deleteMany({ where: { userId: u.id } })
    await db.attendanceRecord.deleteMany({ where: { userId: u.id } })
    await db.user.delete({ where: { id: u.id } })
    console.log(`✓ Test account removed: ${u.username}`)
  }

  // ---- Remove uploaded profile pictures (reset to default avatars) ----
  try {
    const avatarsDir = path.join(process.cwd(), 'db', 'avatars')
    if (existsSync(avatarsDir)) {
      for (const f of readdirSync(avatarsDir)) unlinkSync(path.join(avatarsDir, f))
    }
    for (const u of await db.user.findMany({})) {
      await db.user.update({ where: { id: u.id }, data: { avatarUrl: `/avatars/${u.username}.png` } })
    }
    console.log('✓ Uploaded profile pictures removed, default avatars restored')
  } catch { /* no avatars dir */ }

  // ---- Remove orphaned uploaded files on disk ----
  try {
    const uploadsDir = path.join(process.cwd(), 'db', 'uploads')
    if (existsSync(uploadsDir)) {
      for (const f of readdirSync(uploadsDir)) unlinkSync(path.join(uploadsDir, f))
    }
    console.log('✓ Uploaded file storage cleared')
  } catch { /* no uploads dir */ }

  // ---- Reset ID counters (SQLite sequences) so codes start at 0001 ----
  const tables = [
    'Client', 'Order', 'OrderRevision', 'Task', 'Payment', 'Invoice', 'InvoiceItem',
    'Expense', 'FileRecord', 'Comment', 'Notification', 'ActivityLog',
    'MaintenancePlan', 'MaintenanceSubscription', 'MaintenanceInvoice',
    'MaintenancePayment', 'MaintenanceTicket', 'MaintenanceActivityLog', 'AttendanceRecord',
  ]
  for (const t of tables) {
    try {
      await db.$executeRawUnsafe(`DELETE FROM sqlite_sequence WHERE name = '${t}'`)
    } catch { /* table has no sequence row */ }
  }
  console.log('✓ ID counters reset (next codes will be CL-0001, AGS-ORD-0001, …)')

  // ---- Restore seeded credentials ----
  const creds = parseCredentials()
  let restored = 0
  for (const [username, password] of Object.entries(creds)) {
    const user = await db.user.findUnique({ where: { username } })
    if (!user) continue
    await db.user.update({
      where: { id: user.id },
      data: {
        passwordHash: hashPassword(password),
        mustChangePassword: true,
        resetCode: null,
        resetCodeExpiresAt: null,
        isActive: true,
      },
    })
    restored++
    console.log(`✓ ${user.name}: original seeded password restored, first-login change enforced`)
  }

  // ---- Leave one clean activity-log entry ----
  await db.activityLog.create({
    data: { action: 'system', entity: 'settings', summary: 'System prepared for first use — test data removed, accounts secured' },
  })

  console.log(`\nCleanup complete. ${restored} account(s) restored to seeded credentials.`)
  console.log('The system now starts empty and secure, exactly as delivered.')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
